# TempGraphViz

**TempGraphViz** is an interactive GUI designed for exploring, analyzing, and visualizing **temporal graphs** — graphs that evolve over time.

## Installation & usage

You can install TempGraphViz with pip using:

pip install tempgraphviz

To start the GUI:

python -m tempgraphviz.main_gui

If you do not have Python installed, or prefer not to use it, you can download TempGraphViz as an executable [here](link).

## Quickstart

Your data should be stored in a single folder as **.csv files**, where each file represents the graph at a specific time point.

Steps to get started:

1. Click **Open** in the GUI to select the folder containing your `.csv` files.
2. Use the **Sub-graph selector** to choose one or multiple layers to visualize or analyze.
3. Adjust the **layout** and **metrics** to explore structural properties.
4. Optionally, apply a **graph cut** for better readability on large graphs.
5. Switch between **Graph**, **Histogram**, and **Animation** views to gain different insights.

<img src="quickstart_numbered.png" alt="Quickstart" width="400">

## Main Functionalities

### Structure Visualization

Visualize temporal graphs as a 3D stack to see how connections evolve over time. You can compute various [metrics](metrics.md) to quantify node importance — important nodes will appear larger.

<img src="3D_view.png" alt="Graph Structure" width="400">

### Metrics Distribution

Visualize how metrics evolve over time using histograms.

<img src="histo_view.png" alt="Metrics Distribution" width="400">

### Temporal Layout

You can also display the results as a temporal layout.

<img src="temporal_layout.png" alt="temporal_layout" width="400">


### Graph Animation

Animate the temporal evolution of your graph to better understand dynamics.

<img src="graph_animation.gif" alt="Graph Animation" width="400">

## License

This project is licensed under the MIT License.
